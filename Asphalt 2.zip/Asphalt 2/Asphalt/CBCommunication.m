//
//  CBCommunication.m
//  Asphalt
//
//  Created by Morgan Collino on 10/31/14.
//
//

#import "CBCommunication.h"
#import "Services.h"

@interface CBCommunication () <CBPeripheralDelegate>
@property (strong, nonatomic) CBCentralManager *centralManager;
@property (strong, nonatomic) CBPeripheral *discoveredPeripheral;
@property (strong, nonatomic) NSMutableData *data;
@property (strong, nonatomic) CBPeripheralManager *peripheralManager;
@property (retain, nonatomic) NSUUID *identifier;

@property (strong, nonatomic) NSMutableDictionary *ledCaracteristics;
@property (strong, nonatomic) NSMutableDictionary *caracteristics;
@end

@implementation CBCommunication

- (CBPeripheral *)currentPeripheral {
	return _discoveredPeripheral;
}

- (NSDictionary *)characteristics {
	return _caracteristics;
}

- (instancetype) init
{
	if (self = [super init])
	{
		_centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
		//[_centralManager scanForPeripheralsWithServices: @"180A" options: nil];
		_data = [[NSMutableData alloc] init];
		_peripheralManager = [[CBPeripheralManager alloc] initWithDelegate:self queue:nil];
		_ledCaracteristics = [[NSMutableDictionary alloc] initWithCapacity:4];
	}
	return self;
}

+ (instancetype) sharedCommunication {
	
	static CBCommunication *shared = nil;
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		shared = [[self alloc] init];
	});
	return shared;
}

#pragma mark - Peripheral Manager Delegate

- (void)peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral {
	if (peripheral.state == CBPeripheralManagerStatePoweredOn) {
		[self.peripheralManager startAdvertising:@{
												   CBAdvertisementDataLocalNameKey: [[UIDevice currentDevice] name]
												   }];
	} else {
		[self.peripheralManager stopAdvertising];
	}
}

// Identifier : Bike Assistant: 3378FD5A-39E0-3E3B-6205-65741D7E1267

#pragma mark - Central Manager Delegate

- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI {
	
	
	NSLog(@"centralManager:didDiscoverPeripheral:%@ advertisementData:%@ RSSI %@",
		  peripheral,
		  [advertisementData description],
		  RSSI);
	NSLog(@"peripheral.UUID: %@", peripheral.UUID);
	
	_discoveredPeripheral = peripheral;
	
	//[_centralManager connectPeripheral:_discoveredPeripheral
	// options:[NSDictionary dictionaryWithObject:@YES
	//forKey:CBConnectPeripheralOptionNotifyOnDisconnectionKey]];
	
	//[_centralManager stopScan];
	/*NSLog(@"Discovered %@ at %@", peripheral.name, RSSI);
	NSLog(@"Identifier: %@", peripheral.identifier.UUIDString);
	self.identifier = peripheral.identifier;;
	NSLog(@"Description: %@", peripheral.description);
	NSLog(@"Services: %@", peripheral.services);
	NSLog(@"=======================================");

	if (_discoveredPeripheral != peripheral) {
		// Save a local copy of the peripheral, so CoreBluetooth doesn't get rid of it
		_discoveredPeripheral = peripheral;
		
		// And connect
		NSLog(@"Connecting to peripheral %@", peripheral);
		[_centralManager connectPeripheral:peripheral options:nil];
	}*/
}

- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral {
	NSLog(@"centralManager:didConnectPeripheral:%@", peripheral);
	[peripheral setDelegate:self];
	NSLog(@"discovering services...");
	[peripheral discoverServices:nil];
	if ([self.delegate respondsToSelector:@selector(didConnectOnBluetoothDevice)]) {
		[self.delegate didConnectOnBluetoothDevice];
	}
}

// E519A981-EB1F-ED37-84C9-B73F2488DA05
// E519A981-EB1F-ED37-84C9-B73F2488DA05
- (void)centralManagerDidUpdateState:(CBCentralManager *)central {
	// You should test all scenarios
	if (central.state != CBCentralManagerStatePoweredOn) {
		return;
	}
	
	if (central.state == CBCentralManagerStatePoweredOn) {
		// Scan for devices
		
		// Real device: @[[CBUUID UUIDWithString:@"FFF0"]]
		[_centralManager scanForPeripheralsWithServices:nil options:@{ CBCentralManagerScanOptionAllowDuplicatesKey: @NO }];
		NSLog(@"Scanning started");
	}
}

- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
	NSLog(@"centralManager:didFailToConnectPeripheral:%@ error:%@", peripheral, [error localizedDescription]);
	if (self.discoveredPeripheral) {
		[self.discoveredPeripheral setDelegate:nil];
		self.discoveredPeripheral = nil;
	}

}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error {
	
	NSLog(@"didDiscoverServices: %@", error);
	if (error) {
		[self cleanup];
		return;
	}
 
	for (CBService *service in peripheral.services) {
		NSLog(@"Service.UUID: %@", service.UUID);
		NSLog(@"Service.Characteristics: %@",  service.characteristics);
		//NSLog(@"Service.", service.);
		[peripheral discoverCharacteristics:nil forService:service];
	}
	// Discover other characteristics
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error {
	if (error) {
		[self cleanup];
		return;
	}
	NSLog(@"didDiscoverCharacteristicsForService: UIID:%@", service.UUID.UUIDString);

	for (CBCharacteristic *characteristic in service.characteristics) {
		NSLog(@"\tcharacteristic.UUID: %@", characteristic.UUID);
		NSLog(@"\tcharacteristic.descriptors: %@",  characteristic.descriptors);

		//if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:TRANSFER_CHARACTERISTIC_UUID]]) {
			[peripheral setNotifyValue:YES forCharacteristic:characteristic];
		
		[self.caracteristics setObject:characteristic forKey:characteristic.UUID.UUIDString];
		
		if ([characteristic.UUID.UUIDString containsString:@"FFF"]) {
			[self.ledCaracteristics setObject:characteristic forKey:characteristic.UUID.UUIDString];
		}

		
		if ([characteristic.UUID.UUIDString isEqualToString:@"FFF3"]) {
			NSLog(@"TO COLOR !!!");
			[self changeLEDColor:[UIColor blueColor]];
		}
		
		/**
		 *  @brief  NE PAS DELETE --> WRITE TEST POUR LA LED (R:FFF1,G:FFF2,B:FFF3)
		 *  @since 0.1
		 */
	
		 
		/*if ([characteristic.UUID.UUIDString isEqual: @"FFF2"]) {
			uint8_t val = 1;
			NSData* valData = [NSData dataWithBytes:(void*)&val length:sizeof(val)];
			[peripheral writeValue:valData forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
		}*/
		//NSData *dataToWrite = [[NSData alloc] initw];
		//[peripheral writeValue:dataToWrite forCharacteristic:interestingCharacteristic
        //type:CBCharacteristicWriteWithResponse];}
	}
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
	if (error) {
		NSLog(@"Error: %@", error);
		return;
	}
	
	NSString *stringFromData = [[NSString alloc] initWithData:characteristic.value encoding:NSUTF8StringEncoding];
	
	NSLog(@"Log: %@", characteristic.value);
	NSLog(@"Log: %@", stringFromData);
	// Have we got everything we need?
	if ([stringFromData isEqualToString:@"EOM"]) {
		
		//[_textview setText:[[NSString alloc] initWithData:self.data encoding:NSUTF8StringEncoding]];
		
		[peripheral setNotifyValue:NO forCharacteristic:characteristic];
		//[_centralManager cancelPeripheralConnection:peripheral];
	}
	
	[_data appendData:characteristic.value];
}


- (void)peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
	
	if (![characteristic.UUID isEqual:[CBUUID UUIDWithString:TRANSFER_CHARACTERISTIC_UUID]]) {
		return;
	}
	
	if (characteristic.isNotifying) {
		NSLog(@"Notification began on %@", characteristic);
	} else {
		// Notification has stopped
		NSLog(@"NOTIFICATION Stopped! Abort /!\\");
		//[_centralManager cancelPeripheralConnection:peripheral];
	}
}

- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
	_discoveredPeripheral = nil;

	if ([self.delegate respondsToSelector:@selector(didDisconnectOnBluetoothDevice)]) {
		[self.delegate didDisconnectOnBluetoothDevice];
	}
	
	NSLog(@"centralManager:didDisconnectPeripheral:%@ error:%@", peripheral, [error localizedDescription]);
	if (self.discoveredPeripheral) {
		[self.discoveredPeripheral setDelegate:nil];
		self.discoveredPeripheral = nil;
	}
}


- (void)centralManager:(CBCentralManager *)central didRetrievePeripherals:(NSArray *)peripherals {
	NSLog(@"peripherals retrieved: %@", peripherals);
}

- (void)centralManager:(CBCentralManager *)central didRetrieveConnectedPeripherals:(NSArray *)peripherals{
	NSLog(@"didRetrieveConnectedPeripherals :%@", peripherals);
}

- (void)cleanup {
	
	NSLog(@"____CLEANUP_____");
	// See if we are subscribed to a characteristic on the peripheral
	if (_discoveredPeripheral.services != nil)
	{
		for (CBService *service in _discoveredPeripheral.services)
		{
			if (service.characteristics != nil)
			{
				for (CBCharacteristic *characteristic in service.characteristics)
				{
					if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:TRANSFER_CHARACTERISTIC_UUID]])
					{
						if (characteristic.isNotifying)
						{
							[_discoveredPeripheral setNotifyValue:NO forCharacteristic:characteristic];
							return;
						}
					}
				}
			}
		}
	}
 
	[_centralManager cancelPeripheralConnection:_discoveredPeripheral];
}

- (NSDictionary *)ledCharacteristics {
	return _ledCaracteristics;
}

- (void)changeLEDColor:(UIColor *)color {
	
	const CGFloat *colors = CGColorGetComponents(color.CGColor);
	NSLog(@"R:%.2fG:%.2fB:%2f", colors[0], colors[1], colors[2]);
	NSLog(@"self.ledCaracteristics: %@", self.ledCaracteristics);
	if ([self.ledCaracteristics objectForKey:@"FFF1"]) {
		int8_t val = (uint8_t)colors[0];
		NSData* valData = [NSData dataWithBytes:(void*)&val length:sizeof(val)];
		CBCharacteristic *characteristic = [self.ledCaracteristics objectForKey:@"FFF1"];
		[self.discoveredPeripheral writeValue:valData forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
		[self.discoveredPeripheral readValueForCharacteristic:characteristic];
	}
	
	if ([self.ledCaracteristics objectForKey:@"FFF2"]) {
		uint8_t val = (uint8_t)colors[1];
		NSData* valData = [NSData dataWithBytes:(void*)&val length:sizeof(val)];
		CBCharacteristic *characteristic = [self.ledCaracteristics objectForKey:@"FFF2"];
		[self.discoveredPeripheral writeValue:valData forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
		[self.discoveredPeripheral readValueForCharacteristic:characteristic];
	}
	
	if ([self.ledCaracteristics objectForKey:@"FFF3"]) {
		int8_t val = (uint8_t)colors[2];
		NSData* valData = [NSData dataWithBytes:(void*)&val length:sizeof(val)];
		CBCharacteristic *characteristic = [self.ledCaracteristics objectForKey:@"FFF3"];
		[self.discoveredPeripheral writeValue:valData forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
		[self.discoveredPeripheral readValueForCharacteristic:characteristic];
	}
}

@end
