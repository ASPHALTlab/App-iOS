//
//  CBCommunication.h
//  Asphalt
//
//  Created by Morgan Collino on 10/31/14.
//
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <UIKit/UIKit.h>

@protocol CBCommunicationProtocol;

@interface CBCommunication : NSObject<CBCentralManagerDelegate, CBPeripheralManagerDelegate>

+ (instancetype) sharedCommunication;
- (void)changeLEDColor:(UIColor *)color;
- (CBPeripheral *)currentPeripheral;
- (NSDictionary *)ledCharacteristics;
- (NSDictionary *)characteristics;

@property (nonatomic, weak) id<CBCommunicationProtocol> delegate;

@end


@protocol CBCommunicationProtocol <NSObject>

- (void)didConnectOnBluetoothDevice;
- (void)didDisconnectOnBluetoothDevice;

@end