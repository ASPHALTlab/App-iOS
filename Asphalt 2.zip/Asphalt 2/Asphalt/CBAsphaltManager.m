//
//  CBAsphaltManager.m
//  Asphalt
//
//  Created by Morgan Collino on 1/25/15.
//
//

#import "CBAsphaltManager.h"
#import "CBCommunication.h"
#import "CentralManager.h"

@implementation CBAsphaltManager

+ (instancetype)sharedManager {
	static CBAsphaltManager *shared = nil;
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		shared = [[self alloc] init];
	});
	return shared;
}

- (void)sendColor:(uint8_t [3])colors {
	// write [0] R
	// write [1] G
	// write [2] B
	CBPeripheral *peripheral = [CBCommunication sharedCommunication].currentPeripheral;
	NSDictionary *ledCaracteristics = [CBCommunication sharedCommunication].ledCharacteristics;
	
	if ([ledCaracteristics objectForKey:@"FFF1"]) {
		int8_t val = (uint8_t)colors[0];
		NSData* valData = [NSData dataWithBytes:(void*)&val length:sizeof(val)];
		CBCharacteristic *characteristic = [ledCaracteristics objectForKey:@"FFF1"];
		[peripheral writeValue:valData forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
		[peripheral readValueForCharacteristic:characteristic];
	}
	
	if ([ledCaracteristics objectForKey:@"FFF2"]) {
		uint8_t val = (uint8_t)colors[1];
		NSData* valData = [NSData dataWithBytes:(void*)&val length:sizeof(val)];
		CBCharacteristic *characteristic = [ledCaracteristics objectForKey:@"FFF2"];
		[peripheral writeValue:valData forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
		[peripheral readValueForCharacteristic:characteristic];
	}
	
	if ([ledCaracteristics objectForKey:@"FFF3"]) {
		int8_t val = (uint8_t)colors[2];
		NSData* valData = [NSData dataWithBytes:(void*)&val length:sizeof(val)];
		CBCharacteristic *characteristic = [ledCaracteristics objectForKey:@"FFF3"];
		[peripheral writeValue:valData forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
		[peripheral readValueForCharacteristic:characteristic];
	}
	
}

- (void)sendCurrentTime {
	CBPeripheral *peripheral = [CBCommunication sharedCommunication].currentPeripheral;
	NSDictionary *characteristics = [CBCommunication sharedCommunication].characteristics;;

	if ([characteristics objectForKey:@"1805"]) {
		int8_t val = 0; // NSDate
		NSData* valData = [NSData dataWithBytes:(void*)&val length:sizeof(val)];
		CBCharacteristic *characteristic = [characteristics objectForKey:@"1805"];
		[peripheral writeValue:valData forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
		[peripheral readValueForCharacteristic:characteristic];
	}

}

- (void)search {
	
}

- (void)disconnect {
	CBPeripheral *peripheral = [CBCommunication sharedCommunication].currentPeripheral;
	[[CentralManager sharedCentral].manager cancelPeripheralConnection:peripheral];
}

- (BOOL)isConnected {
	CBPeripheral *peripheral = [CBCommunication sharedCommunication].currentPeripheral;
	return peripheral.state == CBPeripheralStateConnected;
}

@end
