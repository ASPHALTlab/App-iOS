//
//  CBAsphaltManager.h
//  Asphalt
//
//  Created by Morgan Collino on 1/25/15.
//
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface CBAsphaltManager : NSObject

- (void)sendColor:(uint8_t[3])color;
- (void)sendCurrentTime;
- (void)disconnect;
- (void)search;
- (BOOL)isConnected;

+ (instancetype)sharedManager;

@end
